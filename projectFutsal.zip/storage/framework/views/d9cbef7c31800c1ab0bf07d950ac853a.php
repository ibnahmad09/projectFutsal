<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-2xl font-bold mb-6">Riwayat Booking</h1>

    <!-- Desktop Table View -->
    <div class="hidden md:block bg-white rounded-lg shadow-md overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-800 text-white">
                <tr>
                    <th class="p-4 text-left">Kode Booking</th>
                    <th class="p-4 text-left">Lapangan</th>
                    <th class="p-4 text-left">Tanggal</th>
                    <th class="p-4 text-left">Waktu</th>
                    <th class="p-4 text-left">Status</th>
                    <th class="p-4 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="p-4"><?php echo e($booking->booking_code); ?></td>
                    <td class="p-4"><?php echo e($booking->field->name); ?></td>
                    <td class="p-4"><?php echo e($booking->booking_date->format('d M Y')); ?></td>
                    <td class="p-4"><?php echo e($booking->start_time); ?> - <?php echo e($booking->end_time); ?></td>
                    <td class="p-4">
                        <span class="px-2 py-1 rounded-full text-sm
                            <?php if($booking->status == 'confirmed'): ?> bg-green-100 text-green-800
                            <?php elseif($booking->status == 'pending'): ?> bg-yellow-100 text-yellow-800
                            <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                            <?php echo e(ucfirst($booking->status)); ?>

                        </span>
                    </td>
                    <td class="p-4">
                        <a href="<?php echo e(route('user.bookings.show', $booking)); ?>"
                           class="text-green-600 hover:text-green-800">
                            Lihat Detail
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Mobile Card View -->
    <div class="md:hidden space-y-4">
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white rounded-lg shadow-md p-4">
            <div class="flex justify-between items-start mb-3">
                <div>
                    <h3 class="font-semibold text-gray-900"><?php echo e($booking->booking_code); ?></h3>
                    <p class="text-sm text-gray-600"><?php echo e($booking->field->name); ?></p>
                </div>
                <span class="px-2 py-1 rounded-full text-xs
                    <?php if($booking->status == 'confirmed'): ?> bg-green-100 text-green-800
                    <?php elseif($booking->status == 'pending'): ?> bg-yellow-100 text-yellow-800
                    <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                    <?php echo e(ucfirst($booking->status)); ?>

                </span>
            </div>

            <div class="space-y-2 mb-4">
                <div class="flex items-center text-sm">
                    <i class='bx bx-calendar text-gray-500 mr-2'></i>
                    <span><?php echo e($booking->booking_date->format('d M Y')); ?></span>
                </div>
                <div class="flex items-center text-sm">
                    <i class='bx bx-time text-gray-500 mr-2'></i>
                    <span><?php echo e($booking->start_time); ?> - <?php echo e($booking->end_time); ?></span>
                </div>
            </div>

            <div class="pt-3 border-t">
                <a href="<?php echo e(route('user.bookings.show', $booking)); ?>"
                   class="w-full bg-green-600 text-white text-center py-2 px-4 rounded-lg hover:bg-green-700 transition-colors block">
                    Lihat Detail
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6">
        <?php echo e($bookings->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectFutsal\resources\views\user\riwayat.blade.php ENDPATH**/ ?>