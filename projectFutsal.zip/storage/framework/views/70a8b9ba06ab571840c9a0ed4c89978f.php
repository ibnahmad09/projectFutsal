<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e($report->title); ?></title>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { color: #2d3748; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f7fafc; }
        .text-right { text-align: right; }
    </style>
</head>
<body>
    <h1><?php echo e($report->title); ?></h1>
    <p>Periode: <?php echo e($report->start_date->format('d M Y')); ?> - <?php echo e($report->end_date->format('d M Y')); ?></p>

    <?php if($report->type === 'financial'): ?>
        <h2>Financial Summary</h2>
        <table>
            <tr>
                <th>Total Revenue (Online + Manual)</th>
                <td class="text-right">Rp<?php echo e(number_format($data['total_revenue'], 0, ',', '.')); ?></td>
            </tr>
            <tr>
                <th>Pendapatan Online</th>
                <td class="text-right">Rp<?php echo e(number_format($data['online_revenue'], 0, ',', '.')); ?></td>
            </tr>
            <tr>
                <th>Pendapatan Manual</th>
                <td class="text-right">Rp<?php echo e(number_format($data['manual_revenue'], 0, ',', '.')); ?></td>
            </tr>
            <?php $__currentLoopData = $data['payment_statuses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e(ucfirst($status)); ?> Transactions</th>
                <td class="text-right"><?php echo e($count); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <h2>Transaction Details</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th class="text-right">Amount</th>
                    <th>Status</th>
                    <th>Type</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data['transactions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($transaction->payment_date->format('d M Y')); ?></td>
                    <td class="text-right">Rp<?php echo e(number_format($transaction->amount, 0, ',', '.')); ?></td>
                    <td><?php echo e(ucfirst($transaction->status)); ?></td>
                    <td><?php echo e(isset($transaction->is_manual) ? 'Manual' : 'Online'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <?php if($report->type === 'booking'): ?>
        <h2>Booking Summary</h2>
        <table>
            <tr>
                <th>Total Bookings</th>
                <td class="text-right"><?php echo e($data['total_bookings']); ?></td>
            </tr>
            <tr>
                <th>Most Popular Field</th>
                <td><?php echo e($data['most_popular_field']); ?></td>
            </tr>
            <tr>
                <th>Total Revenue</th>
                <td class="text-right">Rp<?php echo e(number_format($data['total_revenue'], 0, ',', '.')); ?></td>
            </tr>
        </table>
    <?php endif; ?>

    <?php if($report->type === 'user'): ?>
        <h2>User Summary</h2>
        <table>
            <tr>
                <th>Total Users</th>
                <td class="text-right"><?php echo e($data['total_users']); ?></td>
            </tr>
            <tr>
                <th>New Users</th>
                <td class="text-right"><?php echo e($data['new_users']); ?></td>
            </tr>
            <tr>
                <th>Active Users</th>
                <td class="text-right"><?php echo e($data['active_users']); ?></td>
            </tr>
        </table>
    <?php endif; ?>

    <!-- Add similar sections for booking and user reports -->
</body>
</html><?php /**PATH C:\laragon\www\projectFutsal\resources\views\admin\reports\pdf.blade.php ENDPATH**/ ?>