<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('user.bookings.show', $payment->booking)); ?>"
       class="mt-6 inline-block bg-green-600 text-white px-6 py-3 rounded-lg">
        Lihat Detail Booking
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectFutsal\resources\views\user\callback.blade.php ENDPATH**/ ?>