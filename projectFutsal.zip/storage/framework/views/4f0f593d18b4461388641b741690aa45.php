<?php $__env->startSection('content'); ?>
<div class="p-6">
    <h1 class="text-2xl font-bold mb-6">Manajemen User</h1>

    <div class="cyber-table rounded-lg overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-800">
                <tr>
                    <th class="p-4 text-left">Nama</th>
                    <th class="p-4 text-left">Email</th>
                    <th class="p-4 text-left">No. HP</th>
                    <th class="p-4 text-left">Total Booking</th>
                    <th class="p-4 text-left">Bergabung</th>
                    <th class="p-4 text-left">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-700 hover:bg-gray-800 transition">
                    <td class="p-4"><?php echo e($user->name); ?></td>
                    <td class="p-4"><?php echo e($user->email); ?></td>
                    <td class="p-4"><?php echo e($user->phone_number); ?></td>
                    <td class="p-4"><?php echo e($user->bookings_count); ?></td>
                    <td class="p-4"><?php echo e($user->created_at->format('d M Y')); ?></td>
                    <td class="p-4">
                        <div class="flex items-center">
                            <div class="status-dot <?php echo e($user->email_verified_at ? 'bg-green-500' : 'bg-gray-500'); ?>"></div>
                            <span class="ml-2"><?php echo e($user->email_verified_at ? 'Verified' : 'Unverified'); ?></span>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectFutsal\resources\views\admin\users.blade.php ENDPATH**/ ?>