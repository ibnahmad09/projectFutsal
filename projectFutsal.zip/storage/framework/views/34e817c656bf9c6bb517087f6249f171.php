<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gradient-to-b from-green-50 to-white py-8">
    <div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white shadow-2xl rounded-2xl overflow-hidden border border-gray-100">
            <div class="bg-gradient-to-r from-green-600 to-blue-600 text-white py-6 px-8">
                <h2 class="text-3xl font-bold flex items-center">
                    <i class="fas fa-user-plus mr-3"></i><?php echo e(__('Daftar Akun Baru')); ?>

                </h2>
                <p class="text-sm text-gray-100 mt-2">Sudah punya akun?
                    <a href="<?php echo e(route('login')); ?>" class="text-green-200 hover:text-green-100 font-semibold">Masuk disini</a>
                </p>
            </div>

            <div class="p-8">
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="space-y-6">
                        <!-- Name Input -->
                        <div>
                            <label for="name" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                                <i class="fas fa-user text-gray-500 mr-2"></i><?php echo e(__('Nama Lengkap')); ?>

                            </label>
                            <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus
                                   class="w-full px-4 py-3 border rounded-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                                          transition duration-200 ease-in-out">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-sm text-red-600 flex items-center">
                                    <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Email Input -->
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                                <i class="fas fa-envelope text-gray-500 mr-2"></i><?php echo e(__('Alamat Email')); ?>

                            </label>
                            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                   class="w-full px-4 py-3 border rounded-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                                          transition duration-200 ease-in-out">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-sm text-red-600 flex items-center">
                                    <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Password Input -->
                        <div>
                            <label for="password" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                                <i class="fas fa-lock text-gray-500 mr-2"></i><?php echo e(__('Password')); ?>

                            </label>
                            <input id="password" type="password" name="password" required autocomplete="new-password"
                                   class="w-full px-4 py-3 border rounded-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                                          transition duration-200 ease-in-out">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-sm text-red-600 flex items-center">
                                    <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Confirm Password Input -->
                        <div>
                            <label for="password-confirm" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                                <i class="fas fa-lock text-gray-500 mr-2"></i><?php echo e(__('Konfirmasi Password')); ?>

                            </label>
                            <input id="password-confirm" type="password" name="password_confirmation" required autocomplete="new-password"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg
                                          focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
                        </div>

                        <!-- Phone Number Input -->
                        <div>
                            <label for="phone_number" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                                <i class="fas fa-phone text-gray-500 mr-2"></i><?php echo e(__('Nomor Telepon')); ?>

                            </label>
                            <input id="phone_number" type="text" name="phone_number" value="<?php echo e(old('phone_number')); ?>" required autocomplete="tel"
                                   class="w-full px-4 py-3 border rounded-lg <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                                          transition duration-200 ease-in-out">
                            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-sm text-red-600 flex items-center">
                                    <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Address Input -->
                        <div>
                            <label for="address" class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                                <i class="fas fa-map-marker-alt text-gray-500 mr-2"></i><?php echo e(__('Alamat Lengkap')); ?>

                            </label>
                            <input id="address" type="text" name="address" value="<?php echo e(old('address')); ?>" required autocomplete="street-address"
                                   class="w-full px-4 py-3 border rounded-lg <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent
                                          transition duration-200 ease-in-out">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-sm text-red-600 flex items-center">
                                    <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Submit Button -->
                        <div>
                            <button type="submit"
                                    class="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-semibold py-3 px-4 rounded-lg
                                           transition duration-200 ease-in-out transform hover:scale-[1.02] shadow-lg
                                           flex items-center justify-center">
                                <i class="fas fa-user-plus mr-2"></i><?php echo e(__('Daftar Sekarang')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectFutsal\resources\views\auth\register.blade.php ENDPATH**/ ?>