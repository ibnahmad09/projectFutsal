<?php $__env->startSection('title', 'Admin Cyber Dashboard - FUTSALDESA'); ?>

<?php $__env->startSection('content'); ?>


<!-- Add Field Content -->
 <main class="p-6">
    <div class="max-w-4xl mx-auto">
        <div class="hologram-form rounded-xl p-8">
            <!-- Header -->
            <div class="mb-8 border-b border-green-900 pb-4">
                <h1 class="text-3xl font-bold neon-text flex items-center">
                    <i class='bx bx-plus-circle mr-2'></i>
                    Add New Field
                </h1>
                <p class="text-green-400 mt-2">Fill in the field details below</p>
            </div>

            <form method="POST" action="<?php echo e(route('admin.fields.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- Field Name -->
                <div class="mb-4">
                    <label for="name" class="block text-green-400 mb-2">Field Name *</label>
                    <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>"
                           class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none"
                           required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Field Type -->
                <div class="mb-4">
                    <label for="type" class="block text-green-400 mb-2">Field Type *</label>
                    <select id="type" name="type" class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none" required>
                        <option value="">Select Type</option>
                        <option value="indoor" <?php echo e(old('type') == 'indoor' ? 'selected' : ''); ?>>Indoor</option>
                        <option value="outdoor" <?php echo e(old('type') == 'outdoor' ? 'selected' : ''); ?>>Outdoor</option>
                    </select>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Description -->
                <div class="mb-4">
                    <label for="description" class="block text-green-400 mb-2">Description *</label>
                    <textarea id="description" name="description"
                              class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none h-32"
                              required><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Price and Size -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                    <div>
                        <label for="price_per_hour" class="block text-green-400 mb-2">Price/Hour (Rp) *</label>
                        <input type="number" id="price_per_hour" name="price_per_hour" value="<?php echo e(old('price_per_hour')); ?>"
                               class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none"
                               required>
                        <?php $__errorArgs = ['price_per_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="size" class="block text-green-400 mb-2">Field Size *</label>
                        <input type="text" id="size" name="size" value="<?php echo e(old('size')); ?>"
                               class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none"
                               placeholder="e.g., 20m x 40m" required>
                        <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Operating Hours -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                    <div>
                        <label for="open_time" class="block text-green-400 mb-2">Opening Time *</label>
                        <input type="time" id="open_time" name="open_time" value="<?php echo e(old('open_time')); ?>"
                               class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none"
                               required>
                        <?php $__errorArgs = ['open_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="close_time" class="block text-green-400 mb-2">Closing Time *</label>
                        <input type="time" id="close_time" name="close_time" value="<?php echo e(old('close_time')); ?>"
                               class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none"
                               required>
                        <?php $__errorArgs = ['close_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Facilities -->
                <div class="mb-4">
                    <label class="block text-green-400 mb-2">Facilities</label>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <?php $__currentLoopData = ['shower', 'parking', 'locker', 'wifi', 'cafe', 'ac']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center space-x-2">
                                <input type="checkbox" name="facilities[]" value="<?php echo e($facility); ?>"
                                       <?php echo e(in_array($facility, old('facilities', [])) ? 'checked' : ''); ?>

                                       class="form-checkbox text-green-400">
                                <span class="capitalize"><?php echo e($facility); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['facilities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Status -->
                <div class="mb-4">
                    <label for="status" class="block text-green-400 mb-2">Status *</label>
                    <select id="status" name="status" class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none" required>
                        <option value="available" <?php echo e(old('status') == 'available' ? 'selected' : ''); ?>>Available</option>
                        <option value="maintenance" <?php echo e(old('status') == 'maintenance' ? 'selected' : ''); ?>>Maintenance</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Images Upload -->
                <div class="mb-6">
                    <label class="block text-green-400 mb-2">Field Images (Max 5)</label>
                    <input type="file" name="images[]" multiple
                           class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 input-glow focus:outline-none"
                           accept="image/*">
                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-400 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex justify-end space-x-4">
                    <a href="<?php echo e(route('admin.fields.index')); ?>"
                       class="px-6 py-2 border border-gray-700 rounded-lg hover:bg-gray-800">
                        Cancel
                    </a>
                    <button type="submit"
                            class="bg-green-600 hover:bg-green-700 px-6 py-2 rounded-lg flex items-center">
                        <i class='bx bx-save mr-2'></i>
                        Save Field
                    </button>
                </div>
            </form>
        </div>
    </div>
</main>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectFutsal\resources\views\admin\create-field.blade.php ENDPATH**/ ?>