<?php $__env->startSection('content'); ?>
<div class="text-center mt-20">
    <h1 class="text-3xl font-bold text-red-600 mb-4">Pembayaran Gagal atau Dibatalkan</h1>
    <p class="text-lg">Silakan coba lagi atau hubungi admin jika mengalami kendala.</p>
    <a href="<?php echo e(route('user.bookings.index')); ?>" class="mt-6 inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">Kembali ke Daftar Booking</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectFutsal\resources\views\user\payment-failed.blade.php ENDPATH**/ ?>