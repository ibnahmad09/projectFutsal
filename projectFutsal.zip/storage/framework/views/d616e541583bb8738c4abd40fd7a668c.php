<?php $__env->startSection('title', 'Daftar Member - FUTSALDESA'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 space-y-8">
    <!-- Header -->
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold flex items-center">
            <i class='bx bx-user mr-2 text-green-400'></i>
            Daftar Member
        </h1>
        <a href="<?php echo e(route('members.create')); ?>"
           class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 flex items-center">
            <i class='bx bx-plus mr-2'></i>
            Tambah Member
        </a>
    </div>

    <!-- Members Table -->
    <div class="bg-gray-800 p-4 rounded-lg">
        <table class="w-full">
            <thead class="bg-gray-700">
                <tr>
                    <th class="p-4 text-left">ID</th>
                    <th class="p-4 text-left">Nama User</th>
                    <th class="p-4 text-left">Tanggal Mulai</th>
                    <th class="p-4 text-left">Minggu Diselesaikan</th>
                    <th class="p-4 text-left">Status</th>
                    <th class="p-4 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-700 hover:bg-gray-750 transition">
                    <td class="p-4"><?php echo e($member->id); ?></td>
                    <td class="p-4"><?php echo e($member->user->name); ?></td>
                    <td class="p-4"><?php echo e($member->start_date); ?></td>
                    <td class="p-4"><?php echo e($member->weeks_completed); ?></td>
                    <td class="p-4">
                        <?php if($member->is_active): ?>
                            <span class="px-3 py-1 rounded-full bg-green-100 text-green-800 text-sm">Aktif</span>
                        <?php else: ?>
                            <span class="px-3 py-1 rounded-full bg-red-100 text-red-800 text-sm">Tidak Aktif</span>
                        <?php endif; ?>
                    </td>
                    <td class="p-4">
                        <button onclick="updateWeeksCompleted(<?php echo e($member->id); ?>)"
                                class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                            Tambah Minggu
                        </button>
                        <form action="<?php echo e(route('members.destroy', $member->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus member ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 ml-2">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        <?php echo e($members->links()); ?>

    </div>
</div>

<script>
function updateWeeksCompleted(memberId) {
    if (confirm('Apakah Anda yakin ingin menambah minggu untuk member ini?')) {
        fetch(`/admin/members/${memberId}/update-weeks`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Content-Type': 'application/json'
            }
        }).then(response => response.json())
          .then(data => {
              if (data.success) {
                  location.reload();
              }
          });
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectFutsal\resources\views\admin\members\index.blade.php ENDPATH**/ ?>